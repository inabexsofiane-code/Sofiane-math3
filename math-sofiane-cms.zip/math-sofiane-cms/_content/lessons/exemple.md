---
title: "مثال — الأعداد المركبة"
level: "2"
stream: "math"
type: "cours"
file: "/uploads/files/exemple-nombres-complexes.pdf"
unit: "الوحدة 2"
pages: 8
year: "2024"
notes: "هذا مثال توضيحي — احذفه وأضف ملفاتك الحقيقية"
featured: true
---
